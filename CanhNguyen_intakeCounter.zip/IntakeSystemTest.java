package intakeCounter;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class IntakeSystemTest 
{

	@Test
	public void testValidInputForMale() 
	{
	    IntakeSystem intakeSystem = new IntakeSystem();

	    int age = 30;
	    int height = 175;
	    int weight = 75;
	    IntakeSystem.ActivityLevel activityLevel = IntakeSystem.ActivityLevel.MODERATE;
	    IntakeSystem.Gender gender = IntakeSystem.Gender.MALE;

	    intakeSystem.calculateDailyCalorieIntake(age, height, weight, activityLevel, gender);

	    double result = intakeSystem.getDailyCalorieIntake();

	    assertEquals(2732.11, result, 0.01);
	}

	@Test
	public void testValidInputForFemale() 
	{
	    IntakeSystem intakeSystem = new IntakeSystem();

	    int age = 30;
	    int height = 160;
	    int weight = 60;
	    IntakeSystem.ActivityLevel activityLevel = IntakeSystem.ActivityLevel.MODERATE;
	    IntakeSystem.Gender gender = IntakeSystem.Gender.FEMALE;

	    intakeSystem.calculateDailyCalorieIntake(age, height, weight, activityLevel, gender);

	    double result = intakeSystem.getDailyCalorieIntake();

	    assertEquals(2120.70, result, 0.01);
	}




    @Test
    public void testInvalidInput() 
    {
        IntakeSystem intakeSystem = new IntakeSystem();

        int age = 0; // Invalid age
        int height = 175;
        int weight = 75;
        IntakeSystem.ActivityLevel activityLevel = IntakeSystem.ActivityLevel.MODERATE;
        IntakeSystem.Gender gender = IntakeSystem.Gender.MALE;

        intakeSystem.calculateDailyCalorieIntake(age, height, weight, activityLevel, gender);

        double result = intakeSystem.getDailyCalorieIntake();

        assertEquals(0.0, result, 0.01);
    }
}
