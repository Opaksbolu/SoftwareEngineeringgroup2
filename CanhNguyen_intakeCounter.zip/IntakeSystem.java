package intakeCounter;

public class IntakeSystem 
{

    private double dailyCalorieIntake;

    public enum ActivityLevel 
    {
        SEDENTARY(1.2), // Little or no exercise
        LIGHT(1.375),   // Light exercise or sports 1-3 days a week
        MODERATE(1.55), // Moderate exercise or sports 3-5 days a week
        ACTIVE(1.725),  // Hard exercise or sports 6-7 days a week
        VERY_ACTIVE(1.9); // Very hard exercise, physical job, or training twice a day

        private double multiplier;

        ActivityLevel(double multiplier) 
        {
            this.multiplier = multiplier;
        }

        public double getMultiplier() 
        {
            return multiplier;
        }
    }
    
    public enum Gender 
    {
        MALE,
        FEMALE
    }

    public void calculateDailyCalorieIntake(int age, int height, int weight, ActivityLevel activityLevel, Gender gender) 
    {
        if (age <= 0 || height <= 0 || weight <= 0) 
        {
            System.out.println("Invalid input data");
            return;
        }

        double baseCalories;

        if (gender == Gender.MALE) 
        {
            // For males
            baseCalories = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
        } else {
            // For females
            baseCalories = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
        }

        dailyCalorieIntake = baseCalories * activityLevel.getMultiplier();

        System.out.println("Daily calorie intake calculated: " + dailyCalorieIntake);
    }


    public double getDailyCalorieIntake() 
    {
        return dailyCalorieIntake;
    }

    public void generateCalorieIntakeNote() 
    {
        if (dailyCalorieIntake > 0) 
        {
            System.out.println("Note with daily calorie intake is generated and downloaded.");
        } 
        
        else 
        {
            System.out.println("Daily calorie intake has not been calculated.");
        }
    }

    public static void main(String[] args) 
    {
        int age = 30;
        int height = 175;
        int weight = 75;
        ActivityLevel activityLevel = ActivityLevel.MODERATE;

        IntakeSystem intakeSystem = new IntakeSystem();


        Gender gender = Gender.MALE;
        intakeSystem.calculateDailyCalorieIntake(age, height, weight, activityLevel, gender);
        double dailyCalorieIntakeMale = intakeSystem.getDailyCalorieIntake();

        if (dailyCalorieIntakeMale > 0) 
        {
            System.out.println("Daily Calorie Intake (Male): " + dailyCalorieIntakeMale);
        } else {
            System.out.println("Unable to calculate daily calorie intake for a male.");
        }

        gender = Gender.FEMALE;
        intakeSystem.calculateDailyCalorieIntake(age, height, weight, activityLevel, gender);
        double dailyCalorieIntakeFemale = intakeSystem.getDailyCalorieIntake();

        if (dailyCalorieIntakeFemale > 0) {
            System.out.println("Daily Calorie Intake (Female): " + dailyCalorieIntakeFemale);
        } else {
            System.out.println("Unable to calculate daily calorie intake for a female.");
        }

        intakeSystem.generateCalorieIntakeNote();
    }

}
