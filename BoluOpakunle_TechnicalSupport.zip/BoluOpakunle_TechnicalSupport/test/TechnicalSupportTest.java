import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TechnicalSupportTest {

    @Test
    public void testContactTechnicalSupport() {
        TechnicalSupport technicalSupport = new TechnicalSupport();

        // Test data
        String testName = "John Doe";
        String testEmail = "john.doe@example.com";

        // Calling the contactTechnicalSupport method
        technicalSupport.contactTechnicalSupport(testName, testEmail);

        // Assertions to check if the contact information is stored correctly
        assertEquals(testName, technicalSupport.getContactName());
        assertEquals(testEmail, technicalSupport.getContactEmail());
    }

    @Test
    public void testFillOutInformation() {
        TechnicalSupport technicalSupport = new TechnicalSupport();

        // Test data
        String testIssueDescription = "I'm having trouble with the application.";

        // Calling the fillOutInformation method
        String result = technicalSupport.fillOutInformation(testIssueDescription);

        // Assertion to check if the correct message is returned
        assertEquals("Ticket created: " + testIssueDescription, result);
    }
}
