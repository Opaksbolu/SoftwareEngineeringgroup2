public class TechnicalSupportApp {
    public static void main(String[] args) {
        // Example usage of TechnicalSupport class
        TechnicalSupport technicalSupport = new TechnicalSupport();
        technicalSupport.contactTechnicalSupport("John Doe", "john.doe@example.com");
        String ticket = technicalSupport.fillOutInformation("I'm having trouble with the application.");
        System.out.println(ticket);
    }
}
