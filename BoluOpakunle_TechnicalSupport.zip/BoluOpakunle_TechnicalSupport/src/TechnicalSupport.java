public class TechnicalSupport {
    // Placeholder variables for storing contact information
    private String contactName;
    private String contactEmail;

    // Method to initiate contact with technical support
    public void contactTechnicalSupport(String name, String email) {
        // Some implementation logic here
        this.contactName = name;
        this.contactEmail = email;
    }

    // Method to fill out information for technical support
    public String fillOutInformation(String issueDescription) {
        // Some implementation logic here
        return "Ticket created: " + issueDescription;
    }

    // Getter methods for testing
    public String getContactName() {
        return contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }
}
