import java.util.Scanner;
import java.util.regex.Pattern;

public class PasswordManager {
    private static final Pattern passwordPattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{12,}$");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Password Manager");
            System.out.println("1. Create an account");
            System.out.println("2. Check a password");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createAccount(scanner);
                    break;
                case 2:
                    checkPassword(scanner);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createAccount(Scanner scanner) {
        System.out.print("Enter a password (at least 12 characters with 1 lowercase, 1 uppercase, 1 number, and 1 special character): ");
        String password = scanner.nextLine();

        if (isValidPassword(password)) {
            System.out.println("Account created successfully.");
        } else {
            System.out.println("Invalid password. Account creation failed.");
        }
    }

    private static void checkPassword(Scanner scanner) {
        System.out.print("Enter a password to check: ");
        String password = scanner.nextLine();

        if (isValidPassword(password)) {
            System.out.println("Password is valid.");
        } else {
            System.out.println("Password is invalid.");
        }
    }

    private static boolean isValidPassword(String password) {
        return passwordPattern.matcher(password).matches();
    }
}
