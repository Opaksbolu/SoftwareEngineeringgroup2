import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class AccountManager {
    public static class Account {
        private final String username;
        private final String password;

        public Account(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }
    }

    private static final List<Account> accounts = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Create an Account");
            System.out.println("2. Check if Account is Present");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1 -> createAccount(scanner);
                case 2 -> checkAccount(scanner);
                case 3 -> {
                    System.out.println("Exiting...");
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createAccount(Scanner scanner) {
        System.out.println("Creating an Account...");

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        if (isUsernameTaken(username)) {
            System.out.println("Username is already taken. Please choose another username.");
            return;
        }

        System.out.print("Enter password (must be 12 characters long, contain at least one uppercase, one lowercase letter, and one special character): ");
        String password = scanner.nextLine();

        if (isPasswordValid(password)) {
            accounts.add(new Account(username, password));
            System.out.println("Account created successfully.");
        } else {
            System.out.println("Invalid password format. Please meet the criteria for the password.");
        }
    }

    private static void checkAccount(Scanner scanner) {
        System.out.println("Checking if Account is Present...");

        System.out.print("Enter the username to check: ");
        String username = scanner.nextLine();

        if (isUsernameTaken(username)) {
            System.out.println("Account is present.");
        } else {
            System.out.println("Account is not present.");
        }
    }

    private static boolean isUsernameTaken(String username) {
        for (Account account : accounts) {
            if (account.getUsername().equals(username)) {
                return true;
            }
            
        }
        return false;
    }

    private static boolean isPasswordValid(String password) {
        // Password must be 12 characters long and meet the criteria
        return password.length() == 12 && Pattern.matches(".*[A-Z].*", password) &&
                Pattern.matches(".*[a-z].*", password) && Pattern.matches(".*[@#$%^&+=].*", password);
    }
}
